# CollegeMap / Dijkstra

## Layout

```
DijkstraSolution/
  CollegeMapLib/   static library: CollegeMap.h/.cpp, Dijkstra.h/.cpp
  Demo/            console app: main.cpp, MTU Map.txt, MTU Map (corrected).txt
  Tests/           Google Test project: test.cpp (65 tests)
```

## Visual Studio 2022 setup

1. **New solution, project 1: Static Library** named `CollegeMapLib`. Delete the generated `pch.*`, `framework.h` and `CollegeMapLib.cpp`. Add the four class files. Project Properties → C/C++ → Precompiled Headers → **Not Using Precompiled Headers** (All Configurations).
2. **Add project 2: Console App** named `Demo`. Replace its `.cpp` with `main.cpp`, and put both map `.txt` files in the Demo project folder (VS runs the program from there).
   - C/C++ → General → Additional Include Directories: `$(SolutionDir)CollegeMapLib`
   - Right-click Demo → Add → Reference → tick `CollegeMapLib`
   - Right-click Demo → Set as Startup Project
3. **Add project 3: Google Test** named `Tests`. In the wizard pick *Link Google Test as: Static library* and *C++ runtime library: Dynamic*. Paste `test.cpp` over the generated one and **keep `#include "pch.h"` as the first line**.
   - Same include directory and reference to `CollegeMapLib` as Demo.
4. All three projects: C/C++ → General → Warning Level **Level3 (/W3)**. Build, then Test → Run All Tests.

## Data issue in Appendix 3

The supplied `MTU Map.txt` is **not symmetric**: row 3 has 14 at column 5 but row 5 has 0 at column 3, and row 6 has 14 at column 3 but row 3 has 0 at column 6. The original GeeksforGeeks graph has a single 3–5 edge of 14. CollegeMap rejects the supplied file (`NotSymmetric`, message names `3->5`). The demo shows that rejection and then loads `MTU Map (corrected).txt` (5→3 = 14, 6→3 = 0). Results from node 0 are identical to the sample output either way.

## Design decisions (Part B material)

**CM2 – validation and reporting.** Errors: missing file, empty file, missing/non-numeric/out-of-range node count (1..1000), too few rows, a row with too few or too many values, non-numeric value, weight outside 0..1,000,000, non-zero diagonal, asymmetric matrix, extra data after the matrix. CRLF line endings and blank lines are tolerated. `load()` returns a `LoadStatus` and `statusMessage()` gives row/column detail. File problems are expected at run time (someone names the wrong file), so they're reported by status code. Programming errors (bad index, invalid weight, querying before running) throw. The file is parsed into a temporary block and only committed if valid, so a failed load leaves the object exactly as it was: a fresh object stays empty, a loaded map keeps its old data.

**CM3 – contiguous block** (`row * nodes + col`). One `new[]` and one `delete[]`, so Constraint 5 is easy to guarantee. Deep copy and comparison are a single loop. It's cache-friendly. With row pointers, an allocation failing at row *k* would mean freeing rows 0..k−1 plus the pointer array.

**CM5 – access and modification.** The map is undirected: `setWeight(a, b, w)` sets a→b and b→a together, and 0 removes the edge. An index out of range throws `std::out_of_range`. A weight outside 0..MaxWeight, or a non-zero weight on the diagonal, throws `std::invalid_argument` and leaves the map unchanged. Reads go through `weight()` / `operator()`, which return by value. `map(0,1) = 5` doesn't compile, so the only way to write is `setWeight`, and symmetry can't be broken.

**Weight/size caps.** 1000 nodes × 1,000,000 max weight is under `INT_MAX`, so no path sum can overflow. This closes the same class of bug as defect 2.

**Operators.** `operator=`, plus `operator==` / `!=` (same name, size and weights), `operator()(row, col)` for read-only element access, and `operator<<` (metadata + matrix). All three are used heavily in the tests.

**CM7 – copying.** The copy constructor holds the only copying logic. `operator=(CollegeMap other)` takes its parameter **by value** and swaps:
- the copy is made by the copy constructor, so the copy logic isn't written twice;
- self-assignment is safe without a check;
- if the copy throws, the target is untouched (strong guarantee);
- the old data is freed when `other` goes out of scope.

It returns `CollegeMap&` so `a = b = c` works. A move constructor means assigning from a temporary doesn't copy.

**CM8 – supplying weights: element access only.** No pointer to the internal block ever escapes, so nothing else can `delete[]` it or keep using it after a reload, and ownership never moves. Returning a copy would make the caller responsible for freeing it and would go out of date when the map changes. The cost is one bounds-checked call per element, n² per run, which is negligible here.

**D1 – association: `const CollegeMap&`.** Storing a copy (the previous version) is composition, not aggregation: the Dijkstra owns its own private map, which dies with it and doesn't see later changes. A reference can't be null, never owns anything, and the destructor only frees the three working arrays. `Dijkstra(const CollegeMap&&) = delete` stops it binding to a temporary that would dangle. Precondition: the map must outlive the Dijkstra.

**D2 – working storage.** Allocated on each `run()`, sized to the map at that moment, so a reload to a different size is handled. New arrays are built in locals and only swapped in when complete, so a failed allocation leaves the previous results intact and leaks nothing. CollegeMap keeps a revision number that changes on every modification. `isStale()` compares it with the revision recorded at the last run, and queries on stale results throw instead of returning wrong answers.

**D3/D4.** Invalid source → `std::out_of_range`; unloaded map → `std::logic_error`. Unreachable nodes give `distanceTo() == Dijkstra::NoRoute` (−1), `routeTo() == "unreachable"`, and "-" / "unreachable" in the table.

**D6 – copying disabled** (`= delete`). A Dijkstra is a calculation tied to one map. A copy would just duplicate the reference plus results that `run()` regenerates. Nothing in the program needs it, and deleting it removes any double-delete risk with no code to get wrong. Declaring the copy operations deleted also suppresses moves.

**Reference code → classes.**
- `dijkstra()` → `run()`
- `minDistance()` → private helper `closestUnprocessed()` in the .cpp (works on the arrays while they're being built)
- `printPath()` → `routeTo()`, iterative, returns a string
- `printSolution()` → `writeResults()` / `saveResults()`
- the global `V` and `graph` disappear: `map.nodes()` and `map(u, v)`

## Reference-code defects

1. **`parent[0] = -1` instead of `parent[src] = -1`.** For any source except 0, `parent[src]` is uninitialised and `printPath` follows garbage. The original **segfaults** with source 3 on the sample map. Fix: every `parent[i] = -1`.
   *Test:* `D3_Execution.Defect1_RoutesFromANonZeroSourceAreCorrect`
2. **`minDistance` uses `<=` against `INT_MAX`.** Once only unreachable nodes remain it still picks one, and `INT_MAX + w` overflows. On a 4-node map with islands {0,1} and {2,3}, the original reports node 2 at distance **−2147483646** via "0 2". (`min_index` is also uninitialised if nothing matches.) Fix: strict `<`, return −1 when nothing is reachable, stop the loop.
   *Test:* `D4_Results.Defect2_UnreachableNodesAreNotGivenADistance`

Both were checked by putting each defect back into a copy of `Dijkstra.cpp`. Defect 1 crashes the suite at its test, while the node-0 sample test still passes, which is the "goes unnoticed" behaviour. Defect 2 fails both unreachable-node tests.

Secondary: `printSolution` hardcodes `src = 0` and ignores `n`, and unreachable nodes print as 2147483647.

## Tests (Part C) – traceability

Test names start with the requirement ID.

| Req | What's covered |
|---|---|
| CM1 | empty object; construct from file; empty and failed objects are safe to display, copy, assign and destroy |
| CM2 | each error code, the supplied asymmetric file, CRLF/blank lines, failed load leaves a fresh object empty, failed reload keeps the old map, good reload replaces it |
| CM3 | every weight in the right cell |
| CM4 | name and node count, metadata display |
| CM5 | `()` matches `weight()`, symmetric set, 0 removes edge, bad index/weight throws and leaves map unchanged, access on empty map |
| CM6 | `<<` output contains metadata and matrix rows |
| CM7 | copy and assign are equal and deep (both directions), self-assignment, chaining, failed copy during assignment leaves target unchanged |
| CM8 | Dijkstra reads current weights through element access |
| CM9 | every `new[]` released after copy/assign/reload/clear/move; nothing leaks on any failed load |
| D1 | won't bind to a temporary (`static_assert`); refers to the same map object |
| D2 | arrays resized when the map is reloaded; modified map → stale → throws; failed allocation at each of the 3 arrays keeps old results, no leak |
| D3 | sample output from node 0; **defect 1**; repeated runs; every route is a real path of the reported length; agrees with Floyd–Warshall for all 81 pairs; invalid source; empty map; 1-node map |
| D4 | **defect 2**; table shows "unreachable" and never 2147483647; table lists every node; query before run; bad destination |
| D5 | saved file matches `writeResults` exactly; unwritable path returns false |
| D6 | not copy-constructible or assignable (`static_assert`) |
| D7 | map unchanged and usable after a Dijkstra is destroyed; exactly 6 allocations and 6 releases for two runs; unused object allocates nothing |

The test file replaces global `operator new[]` / `delete[]` to count allocations and to make a chosen `new[]` throw `std::bad_alloc`. That's how Constraint 5 is tested directly, including the failure paths.

## Verification done

- All code built with GCC 13, `-Wall -Wextra -Wpedantic -Wconversion -Wsign-conversion -Wshadow`, at C++14 and C++17: no warnings.
- 65/65 tests pass (Google Test 1.18).
- Demo run under AddressSanitizer/UBSan and the test suite under Valgrind: no memory errors, no leaks.
- **Not built with MSVC here.** Build once in VS at /W3 and check the Output window for warnings before submitting.
